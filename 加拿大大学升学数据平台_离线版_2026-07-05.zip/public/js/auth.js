// ===== 认证模块（API 客户端） =====
// 密码验证 + 数据解密全部在服务端，前端只存 JWT token

const AUTH = {
  _key: 'admission_token',
  _dataKey: 'admission_pdata',
  _listeners: [],
  _data: null,
  _token: null,

  // ===== 公开 API =====

  isLoggedIn() {
    return !!localStorage.getItem(this._key);
  },

  getCurrentUser() {
    if (!this.isLoggedIn()) return null;
    try {
      const raw = localStorage.getItem(this._key);
      if (!raw) return null;
      const parts = JSON.parse(raw).token.split('.');
      const claims = JSON.parse(atob(parts[1].replace(/-/g, '+').replace(/_/g, '/')));
      return { name: '奇均', display: '奇均' };
    } catch { return null; }
  },

  getData() {
    if (this._data) return this._data;
    try {
      const cached = sessionStorage.getItem(this._dataKey);
      if (cached) { this._data = JSON.parse(cached); return this._data; }
    } catch {}
    return null;
  },

  async login(username, password) {
    try {
      const resp = await fetch('/api/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password })
      });
      const result = await resp.json();
      if (!resp.ok) return { ok: false, msg: result.error || '登录失败' };

      this._token = result.token;
      localStorage.setItem(this._key, JSON.stringify({ token: result.token, ts: Date.now() }));

      // 立即获取个人数据
      await this._fetchPersonalData();

      this._notifyAll();
      return { ok: true, msg: '登录成功', user: { name: '奇均', display: '奇均' } };
    } catch (e) {
      return { ok: false, msg: '网络错误，请重试' };
    }
  },

  logout() {
    localStorage.removeItem(this._key);
    sessionStorage.removeItem(this._dataKey);
    this._token = null;
    this._data = null;
    this._notifyAll();
  },

  async fetchData() {
    if (this._data) return this._data;
    return await this._fetchPersonalData();
  },

  onChange(fn) { this._listeners.push(fn); },

  // ===== 内部方法 =====

  _getToken() {
    if (this._token) return this._token;
    try {
      const raw = localStorage.getItem(this._key);
      if (raw) { this._token = JSON.parse(raw).token; return this._token; }
    } catch {}
    return null;
  },

  async _fetchPersonalData() {
    try {
      const token = this._getToken();
      if (!token) return null;
      const resp = await fetch('/api/me/data', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (!resp.ok) return null;
      const data = await resp.json();
      this._data = data;
      try { sessionStorage.setItem(this._dataKey, JSON.stringify(data)); } catch {}
      return data;
    } catch { return null; }
  },

  async _tryRestoreSession() {
    if (!this.isLoggedIn()) return false;
    if (this._data) return true;
    const data = await this._fetchPersonalData();
    return data !== null;
  },

  _notifyAll() {
    const logged = this.isLoggedIn();
    const user = logged ? this.getCurrentUser() : null;
    this._listeners.forEach(fn => fn(logged, user));
  },

  // 页面初始化：同步更新导航栏UI，异步恢复数据
  initPage() {
    const logged = this.isLoggedIn();
    const user = logged ? this.getCurrentUser() : null;
    this._updateNav(logged, user);

    // 已登录 → 尝试自动恢复数据
    if (logged && !this._data) {
      this._tryRestoreSession().then(success => {
        if (success) this._notifyAll();
      });
    }
  },

  _updateNav(logged, user) {
    const btn = document.getElementById('navAuthBtn');
    if (!btn) return;
    if (logged) {
      btn.className = 'nav-auth-btn logged-in';
      btn.textContent = user ? user.display : '用户';
      btn.title = '点击退出登录';
    } else {
      btn.className = 'nav-auth-btn';
      btn.textContent = '登录';
      btn.title = '登录查看个人数据';
    }
  },

  // ===== 登录弹窗 =====

  showLoginModal() {
    const modal = document.getElementById('loginModal');
    if (modal) modal.classList.add('show');
  },

  hideLoginModal() {
    const modal = document.getElementById('loginModal');
    if (modal) modal.classList.remove('show');
  },

  async handleLoginSubmit() {
    const userInput = document.getElementById('loginUser');
    const passInput = document.getElementById('loginPass');
    const errorEl = document.getElementById('loginError');
    const btn = document.getElementById('loginSubmitBtn');

    const username = userInput.value.trim();
    const password = passInput.value;

    if (!username || !password) {
      errorEl.style.display = 'block';
      errorEl.textContent = '请输入账号和密码';
      return;
    }

    if (btn) { btn.disabled = true; btn.textContent = '验证中...'; }
    errorEl.style.display = 'none';

    const result = await this.login(username, password);

    if (btn) { btn.disabled = false; btn.textContent = '登录'; }

    if (result.ok) {
      this.hideLoginModal();
      userInput.value = '';
      passInput.value = '';
    } else {
      errorEl.style.display = 'block';
      errorEl.textContent = result.msg;
    }
  },

  handleNavAuthClick() {
    if (this.isLoggedIn()) {
      this.logout();
    } else {
      this.showLoginModal();
    }
  }
};

// 全局点击事件：点击模态框外部关闭
document.addEventListener('click', function(e) {
  const modal = document.getElementById('loginModal');
  if (modal && modal.classList.contains('show')) {
    const content = modal.querySelector('.login-modal-content');
    if (content && !content.contains(e.target) && e.target.id !== 'navAuthBtn') {
      AUTH.hideLoginModal();
    }
  }
});

// 回车键提交登录
document.addEventListener('keydown', function(e) {
  if (e.key === 'Enter') {
    const modal = document.getElementById('loginModal');
    if (modal && modal.classList.contains('show')) {
      AUTH.handleLoginSubmit();
    }
  }
});
